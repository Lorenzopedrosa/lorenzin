package br.com.itpacpalmas.api_sig_lab_itpac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSigLabItpacApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiSigLabItpacApplication.class, args);
	}

}
